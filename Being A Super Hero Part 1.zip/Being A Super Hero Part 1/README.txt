READ ME
Turn Off your AntiVirus
And Enjoy Playing This Game :)